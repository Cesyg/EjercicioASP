﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web_umg_bd
{
    public partial class _Default : Page
    {
        estudiantes;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack){
                empleado = new estudiantes();
                empleado.drop_sangre(drop_sangre);
                empleado.grid_estudiante(grid_estudiante);
            }
        }

        protected void btn_agregar_Click(object sender, EventArgs e)
        {
            empleado = new estudiantes();
            if (empleado.agregar(txt_codigo.Text,txt_nombres.Text,txt_apellidos.Text,txt_direccion.Text,txt_telefono.Text,txt_fn.Text,Convert.ToInt32(drop_sangre.SelectedValue)) > 0){
                lbl_mensaje.Text = "Ingreso Exitoso";
                empleado.grid_estudiante(grid_estudiante);

            }
        }

        protected void grid_estudiante_SelectedIndexChanged(object sender, EventArgs e)
        {
            //grid_estudiante.SelectedValue.ToString();
            //grid_estudiante.DataKeys[indice].Values["id"].ToString();
            txt_codigo.Text = grid_estudiante.SelectedRow.Cells[2].Text;
            txt_nombres.Text = grid_estudiante.SelectedRow.Cells[3].Text;
            txt_apellidos.Text = grid_estudiante.SelectedRow.Cells[4].Text;
            txt_direccion.Text = grid_estudiante.SelectedRow.Cells[5].Text;
            txt_telefono.Text = grid_estudiante.SelectedRow.Cells[6].Text;
            DateTime fecha = Convert.ToDateTime(grid_estudiante.SelectedRow.Cells[7].Text);
            txt_fn.Text  = fecha.ToString("yyyy-MM-dd");
            int indice = grid_estudiante.SelectedRow.RowIndex;
            drop_sangre.SelectedValue = grid_estudiante.DataKeys[indice].Values["id_sangre"].ToString();

            btn_modificar.Visible = true;
        }

        protected void grid_estudiante_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            empleado = new estudiantes();
            if (empleado.eliminar( Convert.ToInt32( e.Keys["id"])) > 0){
                lbl_mensaje.Text = "Eliminacion Exitoso...";
                empleado.grid_estudiante(grid_estudiante);
                btn_modificar.Visible = false;
            }
            
            

        }

        protected void btn_modificar_Click(object sender, EventArgs e)
        {


            empleado = new estudiantes();
            if (empleado.modificar( Convert.ToInt32(grid_estudiante.SelectedValue) ,txt_codigo.Text, txt_nombres.Text, txt_apellidos.Text, txt_direccion.Text, txt_telefono.Text, txt_fn.Text, Convert.ToInt32(drop_sangre.SelectedValue)) > 0)
            {
                lbl_mensaje.Text = "Modifacacion Exitoso...";
                empleado.grid_estudiante(grid_estudiante);
                btn_modificar.Visible = false;
            }

            

           
            
        }
    }
}